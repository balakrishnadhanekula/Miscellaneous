window.onload = function () {
	prettyPrint();
}